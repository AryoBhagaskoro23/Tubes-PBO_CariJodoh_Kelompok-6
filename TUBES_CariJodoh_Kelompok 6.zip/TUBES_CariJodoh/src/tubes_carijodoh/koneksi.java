/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes_carijodoh;

import com.mysql.cj.jdbc.MysqlDataSource;
//import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author ASUS
 */
public class koneksi {
    static Connection con;
    
    public static Connection connection(){
            if (con == null) {
            MysqlDataSource data = new MysqlDataSource();
            data.setDatabaseName("pengguna");
            data.setUser("root");
            data.setPassword("");
            try{
                con = data.getConnection();
            }catch (SQLException ex){
                ex.printStackTrace();
            }

//            try {
//                con = data.getConnection();
//            } catch (SQLException ex) {
//                ex.printStackTrace(); 
//            }
        }
        return con;
    }

    public PreparedStatement prepareStatement(String query) {
        PreparedStatement preparedStatement = null;

        try {
            con = connection(); // Buka koneksi ke database
            preparedStatement = con.prepareStatement(query);
        } catch (SQLException e) {
            System.out.println("Gagal membuat PreparedStatement: " + e.getMessage());
        }
        
        return preparedStatement;
    }
    }

