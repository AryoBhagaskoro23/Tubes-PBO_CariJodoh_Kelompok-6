/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes_carijodoh;

import Model.User;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class kriteriaPencocokan {
    private User pria;
    private User wanita;

    public kriteriaPencocokan(User pria, User wanita) {
        this.pria = pria;
        this.wanita = wanita;
    }
    public void setPria(User pria) {
        this.pria = pria;
    }

    public void setWanita(User wanita) {
        this.wanita = wanita;
    }


    public boolean zodiakCocok() {
        List<String> pasanganZodiakPria = getPasanganZodiak(pria.getZodiak());
        List<String> pasanganZodiakWanita = getPasanganZodiak(wanita.getZodiak());

        return pasanganZodiakPria.contains(wanita.getZodiak()) && pasanganZodiakWanita.contains(pria.getZodiak());
    }

    private List<String> getPasanganZodiak(String zodiak) {
        switch (zodiak) {
            case "Aries":
                return List.of("Aries", "Leo", "Gemini", "Aquarius", "Sagittarius");
            case "Taurus":
                return List.of("Cancer", "Virgo", "Pisces", "Capricorn");
            case "Gemini":
                return List.of("Leo", "Libra", "Aquarius", "Aries");
            case "Cancer":
                return List.of("Taurus", "Pisces", "Virgo", "Scorpio");
            case "Leo":
                return List.of("Leo", "Libra", "Gemini", "Sagittarius", "Aries");
            case "Virgo":
                return List.of("Cancer", "Taurus", "Scorpio", "Libra");
            case "Libra":
                return List.of("Aquarius", "Sagittarius", "Leo", "Gemini");
            case "Scorpio":
                return List.of("Virgo", "Capricorn", "Cancer", "Pisces");
            case "Sagittarius":
                return List.of("Libra", "Leo", "Aquarius", "Aries");
            case "Capricorn":
                return List.of("Scorpio", "Taurus", "Pisces", "Virgo");
            case "Aquarius":
                return List.of("Gemini", "Libra", "Aries", "Sagittarius");
            case "Pisces":
                return List.of("Taurus", "Capricorn", "Cancer", "Scorpio");
            default:
                return List.of();
        }
    }

    public boolean kotaCocok() {
        return pria.getKota().equals(wanita.getKota());
    }

    public boolean minatCocok() {
        return pria.getMinat().equals(wanita.getMinat());
    }

    public void displayKecocokan() {
        double minatPersentase = minatCocok() ? 20.0 : 0.0;
        double zodiakPersentase = zodiakCocok() ? 20.0 : 0.0;
        double kotaPersentase = kotaCocok() ? 40.0 : 0.0;

        double totalPersentase = minatPersentase + zodiakPersentase + kotaPersentase;

        System.out.println("Nilai Kecocokan: " + totalPersentase + "%");

        if (totalPersentase > 80.0) {
            System.out.println("Indikator kecocokan: Cocok");
        } else if (totalPersentase > 60.0) {
            System.out.println("Indikator kecocokan: Bisa Diusahakan");
        } else {
            System.out.println("Indikator kecocokan: Tidak Cocok");
        }
    }
}
