/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.JenisUser;
import Model.User;

public interface UserControllerInterface {
    JenisUser validateLogin(String username, String password);
    void loginUser(String username, String password);
    boolean isNotEmpty(String input);
    void updateDataUser(User user);
}

