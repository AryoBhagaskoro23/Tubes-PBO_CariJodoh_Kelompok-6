/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.JenisUser;
import Model.User;
import View.LoginView;
import View.PenggunaView;
import View.RegisterView;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import tubes_carijodoh.koneksi;

/**
 *
 * @author ddlga
 */
public class UserController implements UserControllerInterface {
    koneksi con = new koneksi();

    public void simpanDataUser(JenisUser jenisUser) {
        if (!isNotEmpty(jenisUser.getUsername())) {
            JOptionPane.showMessageDialog(null, "Username tidak boleh kosong!");
            return;
        }

        if (!isNotEmpty(jenisUser.getPassword())) {
            JOptionPane.showMessageDialog(null, "Password tidak boleh kosong!");
            return;
        }

        if (!isNotEmpty(jenisUser.getNama())) {
            JOptionPane.showMessageDialog(null, "Nama tidak boleh kosong!");
            return;
        }

        String query = "INSERT INTO pengguna (username, password, nama, umur, kota, zodiak, minat, jenis_kelamin, is_premium) VALUES (?, ?, ?, ?, ?, ?, ?,?,?)";
        try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
            preparedStatement.setString(1, jenisUser.getUsername());
            preparedStatement.setString(2, jenisUser.getPassword());
            preparedStatement.setString(3, jenisUser.getNama());
            preparedStatement.setInt(4, jenisUser.getUmur());
            preparedStatement.setString(5, jenisUser.getKota());
            preparedStatement.setString(6, jenisUser.getZodiak());
            preparedStatement.setString(7, jenisUser.getMinat());
            preparedStatement.setString(8, jenisUser.getJk());
            preparedStatement.setBoolean(9, jenisUser.getJenis());
            preparedStatement.executeUpdate();
            System.out.println("Data user berhasil disimpan ke dalam database!");
            new RegisterView().dispose();
            new LoginView().setVisible(true);
        } catch (SQLException ex) {
            System.out.println("Terjadi kesalahan saat menyimpan data ke database: " + ex.getMessage());
        }

    }

    @Override
    public JenisUser validateLogin(String username, String password) {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        JenisUser user = null;


        try {

            // Query untuk memeriksa username dan password dari database
            String query = "SELECT * FROM pengguna WHERE username = ? AND password = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();

            // Jika hasil dari query mengembalikan data (username dan password cocok), maka
            // login valid
            if (resultSet.next()) {
                String nama = resultSet.getString("nama");
                int usia = resultSet.getInt("umur");
                String jk = resultSet.getString("jenis_kelamin");
                String minat = resultSet.getString("minat");
                String kota = resultSet.getString("kota");
                String zodiak = resultSet.getString("zodiak");
                Boolean is_premium = resultSet.getBoolean("is_premium");
                user = new JenisUser(username, password, nama, usia, kota, zodiak, minat, jk, is_premium);

            }
        } catch (SQLException e) {
            System.out.println("Kesalahan validasi login: " + e.getMessage());
        }
        return user;
    }

    @Override
    public void loginUser(String username, String password) {
        // Validasi login
         JenisUser user = validateLogin(username, password);

        if (user != null) {
            JOptionPane.showMessageDialog(null, "Login berhasil!");

            // Navigasi ke halaman PenggunaView dengan mengirimkan data user
            PenggunaView penggunaView = new PenggunaView(user);
            penggunaView.setVisible(true);

            // Tutup halaman login atau lakukan tindakan lainnya setelah login berhasil
        } else {
            JOptionPane.showMessageDialog(null, "Login gagal! Username atau password salah.");
            // Lakukan tindakan jika login gagal
        }
    }

    @Override
    public boolean isNotEmpty(String input) {
        return input != null && !input.isEmpty();
    }

    @Override
    public void updateDataUser(User user) {
        if (!isNotEmpty(user.getNama())) {
            JOptionPane.showMessageDialog(null, "Username tidak boleh kosong!");
            return;
        }
        // Pastikan atribut-atribut lain yang tidak boleh kosong telah diperiksa dengan
        // metode isNotEmpty()

        try {
            // Query untuk melakukan update data pengguna berdasarkan ID
            String query = "UPDATE pengguna SET nama=?, umur=?, kota=?, zodiak=?, minat=?, jenis_kelamin=? WHERE username=?";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, user.getNama());
            preparedStatement.setInt(2, user.getUmur());
            preparedStatement.setString(3, user.getKota());
            preparedStatement.setString(4, user.getZodiak());
            preparedStatement.setString(5, user.getMinat());
            preparedStatement.setString(6, user.getJk());
            preparedStatement.setString(7, user.getUsername());

            System.out.print(user.getUsername());

            int updatedRows = preparedStatement.executeUpdate();

            if (updatedRows > 0) {
                JOptionPane.showMessageDialog(null, "Data pengguna berhasil diupdate!");
            } else {
                JOptionPane.showMessageDialog(null, "Tidak ada perubahan data yang disimpan.");
            }
        } catch (SQLException e) {
            System.out.println("Kesalahan saat mengupdate data pengguna: " + e.getMessage());
        }
    }
    
    public String cariBerdasarkanKriteria(String minat, String kota, String zodiak) {
//        List<User> hasilPencarian = new ArrayList<>();
        String hasilPencarian = null;
        String query = "SELECT * FROM pengguna WHERE minat = ? OR kota = ? OR zodiak = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, minat);
            statement.setString(2, kota);
            statement.setString(3, zodiak);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    hasilPencarian =resultSet.getString("nama");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle kesalahan jika terjadi koneksi atau query
        }
        return hasilPencarian;
    }
}
