/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.JenisUser;
import Model.User;
import View.KriteriaPencocokanView;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import tubes_carijodoh.koneksi;

/**
 *
 * @author ASUS
 */
public class KriteriaController {
    koneksi con = new koneksi();
    private int cocok = 0;
    public void view(String username) {
        JenisUser user = null;
        String query = "SELECT * FROM pengguna WHERE username = ?";
        try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    String nama = resultSet.getString("nama");
                    int usia = resultSet.getInt("umur");
                    String jk = resultSet.getString("jenis_kelamin");
                    String minat = resultSet.getString("minat");
                    String kota = resultSet.getString("kota");
                    String zodiak = resultSet.getString("zodiak");
                    Boolean jenisUser = resultSet.getBoolean("is_premium");
                    user = new JenisUser(username, null, nama, usia, kota, zodiak, minat, jk, jenisUser);
                    
                    KriteriaPencocokanView kriteriaPencocokanView = new KriteriaPencocokanView(user);
                    kriteriaPencocokanView.setVisible(true);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception (logging, tampilkan pesan error, dll.)
        }
    }
    
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        String query = "SELECT * FROM pengguna";
        try (PreparedStatement preparedStatement = con.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String nama = resultSet.getString("nama");
                int usia = resultSet.getInt("umur");
                String jk = resultSet.getString("jenis_kelamin");
                String minat = resultSet.getString("minat");
                String kota = resultSet.getString("kota");
                String zodiak = resultSet.getString("zodiak");

                User user = new User(username, null, nama, usia, kota, zodiak, minat, jk);
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception (logging, tampilkan pesan error, dll.)
        }
        return userList;
    }
    
    public void populateUsersInComboBox(JComboBox<String> comboBox) {
        List<User> users = getAllUsers();
        for (User user : users) {
            comboBox.addItem(user.getUsername());
        }
    }
    
    private User getUserByUsername(String username) {
        User user = null;
        String query = "SELECT * FROM pengguna WHERE username = ?";

        try (PreparedStatement preparedStatement = con.prepareStatement(query)) {

            preparedStatement.setString(1, username);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {

                    String nama = resultSet.getString("nama");
                    int usia = resultSet.getInt("umur");
                    String jk = resultSet.getString("jenis_kelamin");
                    String minat = resultSet.getString("minat");
                    String kota = resultSet.getString("kota");
                    String zodiak = resultSet.getString("zodiak");
                    user = new User(username, null, nama, usia, kota, zodiak, minat, jk);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception (logging, tampilkan pesan error, dll.)
        }

        return user;
    }
    
    public boolean minatCocok(String username1, String username2){
        User user1 = getUserByUsername(username1);
        User user2 = getUserByUsername(username2);
        if (user1 != null && user2 != null) {
            if (user1.getMinat().equals(user2.getMinat())) {
//                System.out.println("Minat dari " + user1.getMinat() + " dan " + user2.getMinat() + " sama.");
                cocok += 25;
                return true;
            } else {
//                System.out.println("Minat dari " + user1.getMinat() + " dan " + user2.getMinat() + " tidak sama.");
            }
        } else {
            System.out.println("Pengguna tidak ditemukan.");
        }
        return false;
        
    }
    
    public boolean usiaCocok(String username1, String username2){
        User user1 = getUserByUsername(username1);
        User user2 = getUserByUsername(username2);
        if (user1.getUmur() != -1 && user2.getUmur()!= -1){
            int gap = Math.abs(user1.getUmur()-user2.getUmur());
//            perbedaan umur 5 tahun
            if (gap <= 5) {
                cocok += 15;
                return true;
            }
        } else {
            System.out.println("Pengguna tidak ditemukan.");
        }
        return false;
    }
    
    public boolean zodiakCocok(String username1, String username2){
        User user1 = getUserByUsername(username1);
        User user2 = getUserByUsername(username2);
        List<String> pasanganZodiakUser1 = getPasanganZodiak(this.capitalizeFirstLetter(user1.getZodiak()));
        List<String> pasanganZodiakUser2 = getPasanganZodiak(this.capitalizeFirstLetter(user2.getZodiak()));
//        System.out.println(pasanganZodiakUser1);
//        System.out.println(pasanganZodiakUser2);
        String zodiak1 =this.capitalizeFirstLetter(user2.getZodiak());
        String zodiak2 = this.capitalizeFirstLetter(user1.getZodiak());
        if (pasanganZodiakUser1.contains(zodiak1) && pasanganZodiakUser2.contains(zodiak2)) {
        cocok += 20;
        System.out.println("Kedua zodiak cocok, tambahkan 20 pada variabel cocok.");
        return true;
    }
        return false;
    }
    private List<String> getPasanganZodiak(String zodiak) {
        switch (zodiak) {
            case "Aries":
                return List.of("Aries", "Leo", "Gemini", "Aquarius", "Sagittarius");
            case "Taurus":
                return List.of("Cancer", "Virgo", "Pisces", "Capricorn");
            case "Gemini":
                return List.of("Leo", "Libra", "Aquarius", "Aries");
            case "Cancer":
                return List.of("Taurus", "Pisces", "Virgo", "Scorpio");
            case "Leo":
                return List.of("Leo", "Libra", "Gemini", "Sagittarius", "Aries");
            case "Virgo":
                return List.of("Cancer", "Taurus", "Scorpio", "Libra");
            case "Libra":
                return List.of("Aquarius", "Sagittarius", "Leo", "Gemini");
            case "Scorpio":
                return List.of("Virgo", "Capricorn", "Cancer", "Pisces");
            case "Sagittarius":
                return List.of("Libra", "Leo", "Aquarius", "Aries");
            case "Capricorn":
                return List.of("Scorpio", "Taurus", "Pisces", "Virgo");
            case "Aquarius":
                return List.of("Gemini", "Libra", "Aries", "Sagittarius");
            case "Pisces":
                return List.of("Taurus", "Capricorn", "Cancer", "Scorpio");
            default:
                return List.of();
        }
    }

    public boolean kotaCocok(String username1, String username2){
        User user1 = getUserByUsername(username1);
        User user2 = getUserByUsername(username2);
        if(this.capitalizeFirstLetter(user2.getKota()).equals(this.capitalizeFirstLetter(user1.getKota()))){
            cocok += 40;
            System.out.println("Kedua kota cocok, tambahkan 40 pada variabel cocok.");
            return true;
        }
        return false;
    }
    
    public Object[] displayKecocokan(String Username1, String username2){
        String indicator = "";
        if (this.minatCocok(Username1, username2)){
            indicator += "Minat,";
        }
        if (this.kotaCocok(Username1, username2)) {
            indicator += "Kota, ";
        }
        if (this.usiaCocok(Username1, username2)) {
            indicator += "Usia,";
        }
        if (this.zodiakCocok(Username1, username2)) {
            indicator += "Zodiak";
        }
        Object[] result = {indicator, cocok};
        return result;
       
    }
    
//    public void chat()
    
    public String capitalizeFirstLetter(String text) {
    if (text == null || text.isEmpty()) {
        return text; // Mengembalikan string asli jika null atau kosong
    }

    StringBuilder result = new StringBuilder();
    String[] words = text.split("\\s+"); // Memisahkan teks menjadi array kata-kata

    for (String word : words) {
        if (!word.isEmpty()) {
            // Membuat kata pertama dari setiap kata menjadi huruf kapital
            String firstLetter = word.substring(0, 1).toUpperCase();
            String restOfWord = word.substring(1).toLowerCase();

            result.append(firstLetter).append(restOfWord).append(" ");
        }
    }

    return result.toString().trim(); // Mengembalikan teks yang telah dimodifikasi
    }
    
}
