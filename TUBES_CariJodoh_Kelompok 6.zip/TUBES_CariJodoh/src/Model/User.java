/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ddlga
 */
public class User {
    private String username;
    private String password;
    private String nama;
    private int umur;
    private String kota;
    private String zodiak;
    private String minat;
    private String jk;
//    private final boolean isPremium;

    public User(String username, String password, String nama, int umur, String kota, String zodiak, String minat,
            String jk) {
        this.username = username;
        this.password = password;
        this.nama = nama;
        this.umur = umur;
        this.kota = kota;
        this.zodiak = zodiak;
        this.minat = minat;
        this.jk = jk;
    }

    // Getter dan setter untuk setiap atribut

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public String getKota() {
        return kota;
    }

    public void setKota(String kota) {
        this.kota = kota;
    }

    public String getZodiak() {
        return zodiak;
    }

    public void setZodiak(String zodiak) {
        this.zodiak = zodiak;
    }

    public String getMinat() {
        return minat;
    }

    public void setMinat(String minat) {
        this.minat = minat;
    }

    public String getJk() {
        return jk;
    }

    public void setJk(String jk) {
        this.jk = jk;
    }
    
}
