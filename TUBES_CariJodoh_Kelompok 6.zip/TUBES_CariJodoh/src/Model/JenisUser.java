/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ddlga
 */
public class JenisUser extends User {
    private Boolean isPremium;
    
    public JenisUser(String username, String password, String nama, int umur, String kota, String zodiak, String minat, String jk, Boolean isPremium) {
        super(username, password, nama, umur, kota, zodiak, minat, jk);
        this.isPremium = isPremium;
    }
    
    public Boolean getJenis() {
        return isPremium;
    }

    public void setJenis(Boolean isPremium) {
        this.isPremium = isPremium;
    }
    
}
